// //Task 1  
// var today = new Date();
// document.write("<h1 style='font-size:24px;'>" + today + "</h1>");


 
// // Task 2  
// var monthNames = ["January" , "February" , "March" , "April" , "May" , "June" ,"July" , "August" , "September" , "October" , "November" , "December"];
// var d = new Date();
// alert("Current month: "+ " " + monthNames[d.getMonth()]);



// //Task 3
// var today = new Date();
// today.toString();
// var b =today.toString();
// var c = b.slice(0,3);
// alert("Today is " + " " + c);



// //Task 4
//  var dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
//  var now = new Date();
//  var theDay = now.getDay();
//  var nameOfToday = dayNames[theDay];
// if (nameOfToday === "Sat" || nameOfToday === "Sun"){
//     alert("It's Fun day")
// }



// //Task 5
// var b = new Date();
// if (b < 16) {
//     alert("First fifteen days of the month");
// }
// else 
// {
// alert("Last fifteen days of the month");
// }




// //Task 6
// var a = new Date();
// var b = a.getTime();
// var c = b/(1000*60);
// document.write("<h4 style='font-size:24px;'>" + a + "<br/>" + "Elapsed millisecond since january" + "  " + b + "<br/>" + "Elapsed minutes since january"  + "  " + c + "</h4>");

 

// //Task 7
// var hour;
// if(hour>=12){
//     alert( "It's AM" )
// }
// else {
//     alert("It's PM")
// }

