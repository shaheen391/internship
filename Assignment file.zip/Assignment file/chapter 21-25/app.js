//Task 15
 var inputTxt = (prompt("Enter Password"));
 var a=  /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
if(inputTxt.value.matches(a)) 
{
    alert("Success");
}
else{
    alert("Please enter a valid password");
}


// //Task 18
// var txt = "The quick brown fox jumps over the lazy dog";
// count= 0;
// for (var i = 0; i < txt.length; i++){
//     if(txt.charAt(i)==='c') {
//         count++;
//     }

// }
// document.write("The quick brown fox jumps over the lazy dog"  + "<br/>" + "There are"+ " " + count + " " + "occurence(s) of word 'the'");