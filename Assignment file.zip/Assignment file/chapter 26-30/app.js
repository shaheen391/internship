//Task 1



//Task 2
 


//Task 3



//Task 4


//Task 5



//Task 6
 


//Task 7



//Task 8



//Task 9


//Task 10

